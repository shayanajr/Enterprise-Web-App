@echo off
cd /d "%~dp0"
where node >nul 2>nul
if %errorlevel% equ 0 (
  start "" http://localhost:3000
  node server.mjs
) else (
  start "" "%~dp0dist\index.html"
)
