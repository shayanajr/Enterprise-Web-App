import vm from 'node:vm';
import assert from 'node:assert/strict';
import {readFile,readdir,stat} from 'node:fs/promises';
const source=await readFile(new URL('../src/app.js',import.meta.url),'utf8');
const stub={querySelector:()=>stub,querySelectorAll:()=>[],addEventListener:()=>{},style:{},classList:{add:()=>{}},textContent:''};
const sandbox={document:stub,window:{addEventListener:()=>{}},localStorage:{getItem:()=>null,setItem:()=>{}},structuredClone,Intl,Date,Number,Math,JSON,Set,Map,Array,Promise,matchMedia:()=>({matches:false}),CSS:{escape:x=>x},console};
vm.createContext(sandbox);
const executable=source.replace(/^Promise\.resolve\(\[window\.EnterpriseDesign[^\n]*$/m,'');vm.runInContext(executable,sandbox);
const evaluate=s=>vm.runInContext(s,sandbox);
evaluate("state={...defaults,start:13,end:23,startDate:'2026-05-13',endDate:'2026-05-23',dailyRate:120,protection:3,flexible:true,extras:{driver:true,seat:0,wifi:false,winter:false}};current=IDS.review");
assert.equal(evaluate('days()'),10);assert.equal(evaluate('amount()'),1346.20);
evaluate('state.protection=0');assert.equal(evaluate('amount()'),1606.20);evaluate('current=IDS.details');assert.equal(evaluate('amount()'),1226.20);evaluate('current=IDS.review');
evaluate('state.extras.driver=false;state.extras.seat=1');assert.equal(evaluate('amount()'),1576.20);
evaluate('current=IDS.protection');assert.equal(evaluate('amount()'),1486.20);
evaluate('current=IDS.review;state.dailyRate=84');assert.equal(evaluate('amount()'),1216.20);
evaluate("state.startDate='2026-05-30';state.endDate='2026-06-04'");assert.equal(evaluate('days()'),5);
evaluate("state.country='+1';state.phone='123456789'");assert.equal(evaluate('validPhone()'),false);evaluate("state.phone='4155550142'");assert.equal(evaluate('validPhone()'),true);evaluate("state.phone='415555014299'");assert.equal(evaluate('validPhone()'),false);
evaluate("state.country='+98';state.phone='9123456789'");assert.equal(evaluate('validPhone()'),true);evaluate("state.country='+33';state.phone='123456789'");assert.equal(evaluate('validPhone()'),true);
let imageReferences=0;
for(const file of await readdir(new URL('../src/screens/',import.meta.url))){const html=await readFile(new URL('../src/screens/'+file,import.meta.url),'utf8');assert.ok(!/calc\(50%[-+]/.test(html),'Invalid calc '+file);assert.ok(!/https?:\/\//.test(html),'Remote runtime asset '+file);for(const match of html.matchAll(/src="(assets\/[^"]+)"/g)){const info=await stat(new URL('../dist/'+match[1],import.meta.url));assert.ok(info.size>0);assert.ok(!/\.(png|jpg|jpeg)$/i.test(match[1]));imageReferences++;}}
assert.equal((await readdir(new URL('../src/screens/',import.meta.url))).length,37);
console.log('Passed 13 pricing, date and phone checks. Verified '+imageReferences+' local image references across all 37 Figma states.');

// Desktop previews retain the complete logical Figma reference frame.
for(const [width,height] of [[393,852],[393,720],[390,664],[360,640],[430,932],[852,393],[320,480]]){
 const fit=evaluate(`fitFrame(${width},${height})`);
 assert.ok(fit.width<=width+.001&&fit.height<=height+.001,`${width}×${height}: frame is clipped`);
 assert.ok(Math.abs(fit.width/fit.height-393/852)<.000001,'Figma aspect ratio changed');
 assert.ok(Math.abs(fit.width-width)<.001||Math.abs(fit.height-height)<.001,'Frame does not fill its limiting edge');
}
assert.equal(evaluate('fitFrame(393,852).scale'),1);
assert.equal(evaluate('fitFrame(393,639).scale'),.75);
console.log('Passed 7 desktop reference-frame viewport cases.');

// A keyboard must reduce vertical space without narrowing the mobile canvas.
for(const width of [320,360,390,393,430]){
 for(const height of [360,480,640,720,852]){
  const layout=evaluate(`canvasLayout(${width},${height},true)`);
  assert.equal(layout.width,width,'Mobile has horizontal gutters');
  assert.equal(layout.height,height,'Mobile does not fill visible height');
  assert.ok(Math.abs(layout.scale-width/393)<.000001,'Keyboard changes width scale');
  assert.ok(Math.abs(layout.logicalHeight*layout.scale-height)<.000001,'Canvas overflows visible height');
 }
 const full=evaluate(`canvasLayout(${width},852,true)`),keyboard=evaluate(`canvasLayout(${width},400,true)`);
 assert.equal(full.scale,keyboard.scale,'Keyboard must not shrink text or input width');
}
assert.equal(evaluate('canvasLayout(393,852,false).logicalHeight'),852);
console.log('Passed 25 full-width mobile/keyboard viewport cases; desktop reference stays 852.');
