import {readFile,writeFile,mkdir,copyFile,readdir} from 'node:fs/promises';
import path from 'node:path';
const root=path.resolve(import.meta.dirname,'..');
await mkdir(path.join(root,'dist'),{recursive:true});
const screens={};
for(const name of await readdir(path.join(root,'src/screens'))){if(name.endsWith('.html'))screens[name.slice(0,-5).replace('-',':')]={html:await readFile(path.join(root,'src/screens',name),'utf8')};}
const manifest=JSON.parse(await readFile(path.join(root,'src/screen-manifest.json'),'utf8'));
const typography=JSON.parse(await readFile(path.join(root,'src/figma-typography.json'),'utf8'));
const flows=JSON.parse(await readFile(path.join(root,'src/flows.json'),'utf8'));
await writeFile(path.join(root,'dist/design-data.js'),'window.EnterpriseDesign='+JSON.stringify({screens,manifest,flows,typography})+';\n');
for(const name of ['app.js','app.css','fonts.css','index.html','manifest.webmanifest'])await copyFile(path.join(root,'src',name),path.join(root,'dist',name));
console.log(`Built ${Object.keys(screens).length} Figma screens. No dependencies required.`);
